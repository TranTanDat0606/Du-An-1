<?php
// Nếu muốn load dữ liệu sản phẩm từ CSDL thì viết PHP query ở đây.
// Ví dụ giả lập dữ liệu:
$product = [
    "name" => "Mặt dây chuyền Kim cương Vàng trắng 14K",
    "price" => "11.420.000đ",
    "status" => "Còn hàng – Gọi <strong>1800 545457</strong> để đặt trước",
    "images" => ["img/anh1.jpg", "img/anh2.jpg", "img/anh3.jpg", "img/anh4.jpg"]
];
?>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Chi tiết sản phẩm</title>
  <link rel="stylesheet" href="style.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
</head>
<body>
    <!-- Logo riêng phía trên cùng -->
    <div class="logo-top">
      <img src="img/logo.jpg" alt="DLK Logo" class="logo" />
    </div>
  
    <header class="header">
      <div class="container header-container">
        <nav class="nav-menu">
            <a href="#">Trang Sức</a>
            <a href="#">Trang Sức Cưới</a>
            <a href="#">Đồng Hồ</a>
            <a href="#">Quà Tặng</a>
            <a href="#">Thương Hiệu</a>
            <a href="#">Blog</a>
            <a href="#">Khuyến Mãi</a>
            <div class="search">
                <input type="text" placeholder="Tìm kiếm nhanh" />
                <i class="fas fa-search search-icon-right"></i>
            </div>                                
        </nav>          
      </div>
    </header>
  
    <main class="container product-page">
      <div class="product-gallery">
        <div class="thumbnails-vertical">
        <?php foreach($product['images'] as $img): ?>
        <img src="<?php echo $img; ?>" onmouseover="changeImage(this)" />
        <?php endforeach; ?>
        </div>
        <img id="main-image" src="<?php echo $product['images'][0]; ?>" alt="Main Image" />
      </div>
  
      <div class="product-info">
        <h1><?php echo $product['name']; ?></h1>

        <div class="offers">
          <ul>
            <li>Ưu đãi</li>
          </ul>
        </div>

        <div class="Ưu đãi">
          <ul>
            <li>Cơ hội tận hưởng đặc quyền triệu dặm thưởng từ Vietnam Airlines <a href="#">Xem chi tiết</a></li>
            <li>Cơ hội sở hữu 01 chỉ vàng mỗi ngày <a href="#">Xem chi tiết</a></li>
            <li>Ưu đãi ngay 300.000Đ cho mỗi đơn 10 triệu <a href="#">Xem chi tiết</a></li>
            <li>Tặng trang sức trị giá đến 1 triệu <em>(Chỉ áp dụng tại 100 cửa hàng chọn lọc)</em> <a href="#">Xem chi tiết</a></li>
            <li>Ưu đãi thêm lên đến 300K khi thanh toán quét VNPAY-QR</li>
            <li>Ưu đãi thêm 1.000.000Đ khi thanh toán bằng thẻ TECHCOMBANK <a href="#">Xem chi tiết</a></li>
            <li>Ưu đãi thêm lên đến 500.000Đ khi thanh toán bằng thẻ NCB <a href="#">Xem chi tiết</a></li>
          </ul>
        </div>

        <p class="price"><?php echo $product['price']; ?></p>
        <p class="status"><?php echo $product['status']; ?></p>
        <button class="buy-now">MUA NGAY</button>
        <button class="add-cart">THÊM VÀO GIỎ</button>

        <div class="tabs">
          <button onclick="openTab('specs')">Mô tả sản phẩm</button>
          <button onclick="openTab('policy')">Chính sách</button>
          <button onclick="openTab('faq')">Câu hỏi</button>
        </div>

        <div class="tab-content" id="specs">Chi tiết sản phẩm</div>
        <div class="tab-content" id="policy" style="display: none;">Chính sách đổi trả...</div>
        <div class="tab-content" id="faq" style="display: none;">Câu hỏi thường gặp...</div>
      </div>
    </main>

    <footer class="footer">
      <div class="container">
        <div>
          <strong>DLK</strong> – 170E Phan Đăng Lưu, Q. Phú Nhuận, TP.HCM – MST: 12345678
        </div>
        <div>
          Về DLK: Quan hệ cổ đông, Tuyển dụng, Xuất khẩu, Kinh doanh sỉ
        </div>
        <div>
          Kết nối: <a href="#"><img src="https://cdn-icons-png.flaticon.com/24/145/145802.png" alt="Facebook"/></a>
        </div>
      </div>
    </footer>

    <script>
      function changeImage(imgElement) {
        document.getElementById('main-image').src = imgElement.src;
      }
  
      function openTab(tabId) {
        document.querySelectorAll('.tab-content').forEach(tab => tab.style.display = 'none');
        document.getElementById(tabId).style.display = 'block';
      }
    </script>
</body>
</html>
